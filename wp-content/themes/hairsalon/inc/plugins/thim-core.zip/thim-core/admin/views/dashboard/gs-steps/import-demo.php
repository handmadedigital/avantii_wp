<?php
$thim_dashboard = Thim_Dashboard::instance();
?>

<div class="top">
	<h2>Import demo content</h2>
</div>

<div class="bottom">
	<button class="button button-primary tc-button tc-run-step" data-request="yes">Import</button>
</div>