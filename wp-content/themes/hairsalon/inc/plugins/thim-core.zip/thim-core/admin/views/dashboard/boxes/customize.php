<div class="text-center">
	<a class="button button-primary button-hero load-customize hide-if-no-customize" href="<?php echo wp_customize_url(); ?>"><?php esc_html_e( 'Customize Your Site', 'thim-core' ); ?></a>
</div>