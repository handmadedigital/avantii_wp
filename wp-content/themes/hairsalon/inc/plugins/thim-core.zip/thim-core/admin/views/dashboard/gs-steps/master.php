<div class="tc-step <?php echo esc_attr( $slug ); ?>">
	<?php echo $html; ?>
</div>