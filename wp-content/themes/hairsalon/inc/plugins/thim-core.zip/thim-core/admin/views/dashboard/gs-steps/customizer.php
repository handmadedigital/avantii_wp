<div class="top">
	<div class="row">
		<div class="col-md-6">
			<h2>Customize your website</h2>
			<p class="cation">Pro et purto omnesque, melius malorum fabulas ex quo. Eam ea tritani laoreet adipiscing. Et mnesarchum voluptatibus est, cu ignota tincidunt abhorreant qui.
				Vix ea quot reque, eam facer vocent maiorum ut, ius id probo regione dignis</p>
		</div>

		<div class="col-md-6">
			<iframe width="100%" height="315" src="https://www.youtube.com/embed/z0aYu1AZHpE" frameborder="0" allowfullscreen></iframe>
		</div>
	</div>
</div>

<div class="bottom">
	<a href="<?php echo esc_url( admin_url( 'customize.php?return=' . Thim_Dashboard::get_link_page_by_slug( 'dashboard' ) ) ); ?>" class="button button-primary tc-button tc-run-step">
		Go to customizer
	</a>
</div>

