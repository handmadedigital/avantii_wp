Create mega menu for wordpress theme, base on the "Max Mega Menu" plugin version 2.2.3.1. Thanks Tom Hemsley.
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

###Features

* Drag & drop Mega Menu builder
* Display WordPress Widgets in your menu
* Supports Flyout (traditional) or Mega Menu sub-menu styles
* Add icons to menu items
* 'Hide Text' and 'Disable Link' options per menu item
* Align menu items to the left or right of the menu bar
* Align sub menus to left or right of parent menu item
* Supports multiple menus each with their own configuration